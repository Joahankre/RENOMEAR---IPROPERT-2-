﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

<ComVisible(True)>
Public Class AutomacaoItemNumbers
    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Sincronizar()
        Try
            Dim sinc As New SincronizadorItemNumbers(_app)
            sinc.ExecutarSincronizacao()
        Catch ex As Exception
            MessageBox.Show("Erro na sincronização: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class

