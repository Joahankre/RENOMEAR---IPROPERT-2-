﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor
Imports stdole

<ComVisible(True)>
<Guid("2a97bde3-0f90-48ee-950c-9b7e6dcbfe4f")>
Public Class StandardAddInServerItemNumbers
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoItemNumbers As AutomacaoItemNumbers
    Private botaoSincronizar As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoItemNumbers
        End Get
    End Property

    Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite, ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoItemNumbers = New AutomacaoItemNumbers(_inventorApp)

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
            Dim assembly As Assembly = Assembly.GetExecutingAssembly()

            ' === CARREGAR ÍCONES EMBUTIDOS ===
            Dim smallIcon As IPictureDisp = Nothing
            Dim largeIcon As IPictureDisp = Nothing

            Try
                Dim resources = assembly.GetManifestResourceNames()

                ' Nome dos recursos (ajuste se usar subpasta)
                Dim resource16 = resources.FirstOrDefault(Function(r) r.EndsWith("16x16.ico"))
                Dim resource32 = resources.FirstOrDefault(Function(r) r.EndsWith("32x32.ico"))

                If resource16 IsNot Nothing Then
                    Using stream16 As Stream = assembly.GetManifestResourceStream(resource16)
                        smallIcon = IconToIPictureDisp(New Icon(stream16))
                    End Using
                End If

                If resource32 IsNot Nothing Then
                    Using stream32 As Stream = assembly.GetManifestResourceStream(resource32)
                        largeIcon = IconToIPictureDisp(New Icon(stream32))
                    End Using
                End If

            Catch ex As Exception
                MessageBox.Show("Erro ao carregar ícones embutidos: " & ex.Message)
            End Try

            ' === CRIAÇÃO DO BOTÃO ===
            Try
                botaoSincronizar = DirectCast(controlDefs.Item("MyCompany_SincronizarItemNumbers"), ButtonDefinition)
            Catch
                botaoSincronizar = controlDefs.AddButtonDefinition(
                    "Sincronizar" & vbCrLf & "Item Numbers",
                    "MyCompany_SincronizarItemNumbers",
                    CommandTypesEnum.kEditMaskCmdType,
                    Me.GetType().GUID.ToString("B"),
                    "Sincroniza os Item Numbers de submontagens conforme o BOM estruturado",
                    "Sincronizar" & vbCrLf & "Item Numbers",
                    smallIcon,
                    largeIcon)
            End Try

            AddHandler botaoSincronizar.OnExecute, AddressOf BotaoSincronizar_OnExecute

            ' === ADICIONA O BOTÃO À ABA TOOLS ===
            Dim ribbonAsm As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Assembly")
            Dim tabTools As RibbonTab = ribbonAsm.RibbonTabs("id_TabTools")

            Dim painel As RibbonPanel = Nothing
            Try
                painel = tabTools.RibbonPanels.Item("PainelItemNumbers")
            Catch
                painel = tabTools.RibbonPanels.Add("Item Numbers", "PainelItemNumbers", Me.GetType().GUID.ToString("B"))
            End Try

            Dim existe As Boolean = painel.CommandControls.OfType(Of CommandControl)().
                Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_SincronizarItemNumbers")

            If Not existe Then
                painel.CommandControls.AddButton(botaoSincronizar, True)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao ativar Add-In: " & ex.Message)
        End Try
    End Sub

    Private Sub BotaoSincronizar_OnExecute(ByVal Context As NameValueMap)
        Try
            _automacaoItemNumbers.Sincronizar()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar sincronização: " & ex.Message)
        End Try
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoItemNumbers = Nothing
    End Sub

    Public Sub ExecuteCommand(ByVal commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Método legado não utilizado
    End Sub

    ' === CONVERSÃO DE ÍCONE EMBUTIDO ===
    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Return AxHostConverter.ImageToPictureDisp(icon.ToBitmap())
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub
        Public Shared Function ImageToPictureDisp(image As Drawing.Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class
End Class
