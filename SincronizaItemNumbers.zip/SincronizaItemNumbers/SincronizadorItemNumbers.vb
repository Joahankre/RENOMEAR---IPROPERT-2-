﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Linq
Imports System.Windows.Forms

<ComVisible(True)>
Public Class SincronizadorItemNumbers
    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExecutarSincronizacao()
        Try
            Dim doc As Document = _app.ActiveDocument
            If doc Is Nothing OrElse doc.DocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
                MessageBox.Show("Abra uma montagem antes de rodar esta função.", "Documento inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Dim asmDoc As AssemblyDocument = CType(doc, AssemblyDocument)
            Dim raizDisplayName As String = asmDoc.DisplayName
            Dim erros As New List(Of String)

            ' === GERA O MAPA GLOBAL ===
            Dim mapaGlobal As List(Of Tuple(Of String, String, String)) = ObterMapaCompleto(asmDoc, erros)
            If mapaGlobal.Count = 0 Then
                MessageBox.Show("Nenhum item encontrado no BOM estruturado da montagem.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' === SINCRONIZA SUBMONTAGENS ===
            SincronizarSubmontagensRecursivo(asmDoc, mapaGlobal, raizDisplayName, erros)

            ' === MONTA RELATÓRIO FINAL ===
            Dim resultadoTexto As New StringBuilder()
            resultadoTexto.AppendLine("==== MAPA DE SINCRONIZAÇÃO ====")
            resultadoTexto.AppendLine(FormatarMapaParaTexto(mapaGlobal))

            If erros.Count > 0 Then
                resultadoTexto.AppendLine(vbCrLf & "==== ERROS DETECTADOS ====")
                For Each errMsg As String In erros
                    resultadoTexto.AppendLine("- " & errMsg)
                Next
            Else
                resultadoTexto.AppendLine(vbCrLf & "Nenhum erro detectado.")
            End If

            ShowFormattedResults(resultadoTexto.ToString())
            MessageBox.Show("Sincronização concluída! A montagem principal foi preservada.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro inesperado: " & ex.Message, "Erro geral", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    ' ==== Exibe o relatório em um Form ====
    Private Sub ShowFormattedResults(message As String)
        Dim form As New Form With {.Text = "RESULTADO DA SINCRONIZAÇÃO", .Width = 1000, .Height = 600}
        Dim richText As New RichTextBox With {.Dock = DockStyle.Fill, .ReadOnly = True}
        richText.AppendText(message)
        form.Controls.Add(richText)
        form.ShowDialog()
    End Sub


    ' ==== Formata o mapa para exibição ====
    Private Function FormatarMapaParaTexto(mapa As List(Of Tuple(Of String, String, String))) As String
        Dim sb As New StringBuilder()
        Dim col1Width As Integer = 70
        Dim col2Width As Integer = 30
        sb.AppendLine("PART NUMBER".PadRight(col1Width) & "ITEM NUMBER".PadRight(col2Width) & "CAMINHO HIERÁRQUICO")
        sb.AppendLine(New String("-"c, col1Width + col2Width + 70))
        For Each item In mapa
            sb.AppendLine(item.Item1.PadRight(col1Width) & item.Item2.PadRight(col2Width) & item.Item3)
        Next
        Return sb.ToString()
    End Function


    ' ==== Gera o mapa global do BOM ====
    Private Function ObterMapaCompleto(asm As AssemblyDocument, erros As List(Of String)) As List(Of Tuple(Of String, String, String))
        Dim mapa As New List(Of Tuple(Of String, String, String))()
        Try
            Dim bom As BOM = asm.ComponentDefinition.BOM
            bom.StructuredViewEnabled = True
            bom.StructuredViewFirstLevelOnly = False

            Dim view As BOMView = bom.BOMViews.Cast(Of BOMView)().FirstOrDefault(Function(v) v.ViewType = BOMViewTypeEnum.kStructuredBOMViewType)
            If view Is Nothing Then Return mapa

            For Each row As BOMRow In view.BOMRows
                AdicionarAoMapaRecursivo(row, mapa, asm.DisplayName, erros)
            Next
        Catch ex As Exception
            erros.Add("Erro ao construir mapa completo: " & ex.Message)
        End Try
        Return mapa
    End Function


    ' ==== Adiciona componentes ao mapa ====
    Private Sub AdicionarAoMapaRecursivo(row As BOMRow, mapa As List(Of Tuple(Of String, String, String)), parentPath As String, erros As List(Of String))
        Try
            If row.ComponentDefinitions.Count = 0 Then Exit Sub

            Dim doc As Document = row.ComponentDefinitions.Item(1).Document
            Dim partNumber As String = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
            Dim itemNumber As String = row.ItemNumber
            Dim caminho As String = parentPath & "\" & doc.FullFileName

            If Not String.IsNullOrEmpty(partNumber) Then
                mapa.Add(New Tuple(Of String, String, String)(partNumber, itemNumber, caminho))
            End If

            If row.ChildRows IsNot Nothing Then
                For Each child As BOMRow In row.ChildRows
                    AdicionarAoMapaRecursivo(child, mapa, caminho, erros)
                Next
            End If
        Catch ex As Exception
            erros.Add("Erro ao adicionar ao mapa (" & parentPath & "): " & ex.Message)
        End Try
    End Sub


    ' ==== Sincroniza Item Numbers de uma submontagem ====
    Private Sub SincronizarItemNumbers(mapaGlobal As List(Of Tuple(Of String, String, String)), asm As AssemblyDocument, subPath As String, erros As List(Of String))
        Try
            Dim bom As BOM = asm.ComponentDefinition.BOM
            bom.StructuredViewEnabled = True
            bom.StructuredViewFirstLevelOnly = True

            Dim view As BOMView = bom.BOMViews.Cast(Of BOMView)().FirstOrDefault(Function(v) v.ViewType = BOMViewTypeEnum.kStructuredBOMViewType)
            If view Is Nothing Then Return

            For Each row As BOMRow In view.BOMRows
                Try
                    If row.ComponentDefinitions.Count = 0 Then Continue For
                    Dim doc As Document = row.ComponentDefinitions.Item(1).Document
                    Dim partNumber As String = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                    Dim caminhoAtual As String = subPath & "\" & doc.FullFileName

                    Dim itemNumberCorreto As String = mapaGlobal _
                        .Where(Function(t) t.Item1 = partNumber AndAlso t.Item3 = caminhoAtual) _
                        .Select(Function(t) t.Item2) _
                        .FirstOrDefault()

                    If String.IsNullOrWhiteSpace(itemNumberCorreto) Then
                        itemNumberCorreto = mapaGlobal _
                            .Where(Function(t) t.Item1 = partNumber) _
                            .Select(Function(t) t.Item2) _
                            .FirstOrDefault()
                    End If

                    If Not String.IsNullOrWhiteSpace(itemNumberCorreto) AndAlso row.ItemNumber <> itemNumberCorreto Then
                        Try
                            row.PropertySets.Item("Design Tracking Properties").Item("Item Number").Value = itemNumberCorreto
                        Catch ex As Exception
                            erros.Add($"Falha ao atribuir Item Number para o item {partNumber}: {ex.Message}")
                        End Try
                    End If

                Catch ex As Exception
                    erros.Add($"Erro em linha do BOM ({asm.DisplayName}): {ex.Message}")
                End Try
            Next
        Catch ex As Exception
            erros.Add($"Erro ao sincronizar item numbers de {asm.DisplayName}: {ex.Message}")
        End Try
    End Sub


    ' ==== Sincroniza recursivamente as submontagens ====
    Private Sub SincronizarSubmontagensRecursivo(asm As AssemblyDocument, mapaGlobal As List(Of Tuple(Of String, String, String)), raizDisplayName As String, erros As List(Of String))
        Try
            For Each occ As ComponentOccurrence In asm.ComponentDefinition.Occurrences
                If occ.DefinitionDocumentType = DocumentTypeEnum.kAssemblyDocumentObject Then
                    Try
                        Dim subDoc As Document = Nothing

                        Try
                            subDoc = _app.Documents.Item(occ.Definition.Document.FullFileName)
                        Catch
                            Try
                                subDoc = _app.Documents.Open(occ.Definition.Document.FullFileName, False)
                            Catch exOpen As Exception
                                erros.Add("Falha ao abrir submontagem: " & occ.Name & " - " & exOpen.Message)
                                Continue For
                            End Try
                        End Try

                        Dim subAsm As AssemblyDocument = TryCast(subDoc, AssemblyDocument)
                        If subAsm Is Nothing Then Continue For

                        Dim subPath As String = raizDisplayName & "\" & subAsm.FullFileName

                        SincronizarItemNumbers(mapaGlobal, subAsm, subPath, erros)

                        Try
                            subAsm.Save2(True)
                        Catch exSave As Exception
                            erros.Add("Falha ao salvar " & subAsm.DisplayName & ": " & exSave.Message)
                        End Try

                        SincronizarSubmontagensRecursivo(subAsm, mapaGlobal, raizDisplayName, erros)

                    Catch ex As Exception
                        erros.Add("Erro ao sincronizar submontagem (" & occ.Name & "): " & ex.Message)
                    End Try
                End If
            Next
        Catch ex As Exception
            erros.Add("Erro na sincronização recursiva de " & asm.DisplayName & ": " & ex.Message)
        End Try
    End Sub
End Class
